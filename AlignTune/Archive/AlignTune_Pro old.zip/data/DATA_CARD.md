# Data Card — Demo Instruction & Preference Sets

Purpose: tiny examples to make the pipeline run anywhere.
- **SFT**: JSONL with {"instruction","input","output"}.
- **Preference (DPO/SimPO/ORPO)**: JSONL with {"prompt","chosen","rejected"}.

Replace with your domain data and update `MODEL_CARD.md`.
