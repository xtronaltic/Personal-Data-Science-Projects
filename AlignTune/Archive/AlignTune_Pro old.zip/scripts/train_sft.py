import os, yaml, torch
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from trl import SFTTrainer
from peft import LoraConfig, get_peft_model

def load_cfg(p): 
    with open(p,"r",encoding="utf-8") as f: return yaml.safe_load(f)

def maybe_unsloth(model_name, cfg):
    if not cfg.get("unsloth",{}).get("enable", False):
        return None, None
    try:
        from unsloth import FastLanguageModel
        max_len = cfg["unsloth"].get("max_seq_len", 4096)
        model, tokenizer = FastLanguageModel.from_pretrained(
            model_name=model_name, max_seq_length=max_len, load_in_4bit=cfg["lora"].get("load_in_4bit", True)
        )
        return model, tokenizer
    except Exception as e:
        print("[unsloth] not available or failed, falling back to transformers:", e)
        return None, None

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/base.yaml")
    args = ap.parse_args()
    cfg = load_cfg(args.config)

    model_name = cfg.get("model_name")
    tok_name = cfg.get("tokenizer_name") or model_name
    out_dir = os.path.join(cfg.get("output_dir","outputs"),"sft", os.path.basename(model_name).replace("/","-")+"-lora")

    # Try Unsloth fast loader
    model, tok = maybe_unsloth(model_name, cfg)
    if tok is None:
        tok = AutoTokenizer.from_pretrained(tok_name, use_fast=True)
        if tok.pad_token is None: tok.pad_token = tok.eos_token
    if model is None:
        bnb = None
        if cfg["lora"].get("qlora", True) and cfg["lora"].get("load_in_4bit", True):
            bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16)
        model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", quantization_config=bnb)

    l = cfg["lora"]
    peft_cfg = LoraConfig(r=l["r"], lora_alpha=l["alpha"], lora_dropout=l["dropout"],
                          target_modules=l["target_modules"], task_type="CAUSAL_LM")
    model = get_peft_model(model, peft_cfg)

    ds = load_dataset("json", data_files={"train": cfg["sft"]["train_file"], "validation": cfg["sft"]["val_file"]})
    from scripts.utils import format_sft
    ds = ds.map(lambda ex: {"text": format_sft(ex) + ex["output"]}, remove_columns=ds["train"].column_names)

    trainer = SFTTrainer(
        model=model, train_dataset=ds["train"], eval_dataset=ds["validation"], dataset_text_field="text",
        tokenizer=tok, max_seq_length=cfg["sft"]["max_seq_len"],
        args=dict(output_dir=out_dir,
                  per_device_train_batch_size=cfg["sft"]["per_device_train_batch_size"],
                  per_device_eval_batch_size=cfg["sft"]["per_device_eval_batch_size"],
                  gradient_accumulation_steps=cfg["sft"]["gradient_accumulation_steps"],
                  learning_rate=cfg["sft"]["lr"], warmup_ratio=cfg["sft"]["warmup_ratio"],
                  logging_steps=cfg["sft"]["logging_steps"],
                  evaluation_strategy="steps", eval_steps=cfg["sft"]["eval_steps"],
                  save_steps=cfg["sft"]["save_steps"], bf16=torch.cuda.is_available(),
                  num_train_epochs=1, max_steps=cfg["sft"]["max_steps"],
                  lr_scheduler_type="cosine", report_to=[])
    )
    trainer.train()
    trainer.save_model(out_dir); tok.save_pretrained(out_dir)
    print(f"Saved SFT LoRA to {out_dir}")

if __name__ == "__main__":
    main()
