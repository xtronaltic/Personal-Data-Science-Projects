# Model Card — AlignTune (LoRA + Preference Tuning)

**Base model:** TinyLlama/TinyLlama-1.1B-Chat-v1.0 (default)  
**Methods:** SFT → DPO / SimPO / ORPO (LoRA/QLoRA via Unsloth)  
**Intended Use:** Educational demo; replace with real domain data before production.

## Data
Toy examples are included; replace and update this card.

## Evaluation
- Task metrics: Exact‑Match, ROUGE‑L
- Judge‑based pairwise win‑rate (local judge model)
- Basic safety probe.

## Risks & Limitations
- Demo data is tiny; results not representative.
- Safety checks minimal; use robust guardrails + benchmarks for deployment.

## License
Repo: MIT. Respect base model and dataset licenses.
