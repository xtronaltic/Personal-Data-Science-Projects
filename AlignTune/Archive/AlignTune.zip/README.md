# AlignTune — Modern LLM Fine‑Tuning & Preference Optimization (SFT → DPO/SimPO/ORPO)

A recruiter‑ready, WSL+Blackwell‑friendly project for **parameter‑efficient fine‑tuning** and **preference alignment**:

- **SFT (LoRA/QLoRA)** with **Unsloth** acceleration (imports first, Unsloth LoRA hook).
- **Preference tuning:** **DPO**, **SimPO**, **ORPO** (version‑proof against TRL API changes).
- **Evaluation:** task metrics (EM/ROUGE‑L), judge‑based win rate, basic safety probe.
- **Serving:** FastAPI + Gradio. (Optional vLLM demo.)

## Quickstart (WSL + 5070 Ti, no flash/xformers kernels)

```bash
# New clean env (separate from your TF env)
conda create -n aligntune python=3.11 -y
conda activate aligntune
python -m pip install -U pip

# PyTorch 2.8.0 CUDA 12.8 build
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128

# System compiler for Triton JIT
sudo apt-get update && sudo apt-get install -y build-essential
export CC=gcc
export CXX=g++

# Project deps
pip install -r requirements.txt

# Remove kernels that misbehave on Blackwell
pip uninstall -y xformers flash-attn flash_attn || true

# Train SFT
python -m scripts.train_sft --config configs/base.yaml

# Train DPO (after SFT)
python -m scripts.train_dpo --config configs/base.yaml --sft_ckpt outputs/sft/TinyLlama-lora

# Eval (task metrics)
python -m scripts.eval --config configs/base.yaml --ckpt outputs/dpo/TinyLlama-lora-dpo

# Judge & safety
python -m eval.judge_winrate --config configs/base.yaml   --ckpt_a outputs/dpo/TinyLlama-lora-dpo --ckpt_b outputs/sft/TinyLlama-lora
python -m eval.safety_check --config configs/base.yaml --ckpt outputs/dpo/TinyLlama-lora-dpo

# Serve + demo
uvicorn api.server:app --reload
python app/demo.py --ckpt outputs/dpo/TinyLlama-lora-dpo
```

### Switch to 8B later (QLoRA)
Edit `configs/base.yaml`:
```yaml
model_name: "meta-llama/Llama-3.1-8B-Instruct"
sft:
  per_device_train_batch_size: 1
  gradient_accumulation_steps: 16
dpo:
  per_device_train_batch_size: 1
  gradient_accumulation_steps: 32
```
If OOM: set `sft.max_seq_len: 768`.
