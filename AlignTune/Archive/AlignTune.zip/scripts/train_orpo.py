import unsloth
from unsloth import FastLanguageModel

from torch.backends.cuda import sdp_kernel
sdp_kernel(enable_flash=False, enable_math=True, enable_mem_efficient=True)


import os, yaml, torch, inspect
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import PeftModel, LoraConfig, get_peft_model
from scripts.utils import format_dpo_prompt

try:
    from trl import ORPOTrainer
    _HAS_ORPO = True
except Exception:
    _HAS_ORPO = False

def load_cfg(p):
    with open(p,"r",encoding="utf-8") as f: return yaml.safe_load(f)

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/base.yaml")
    ap.add_argument("--sft_ckpt", required=True)
    args = ap.parse_args()
    if not _HAS_ORPO:
        print("[ORPO] ORPOTrainer not available in your TRL. Use DPO/SimPO or upgrade TRL.")
        return

    cfg = load_cfg(args.config)
    model_name = cfg.get("model_name")
    tok_name   = cfg.get("tokenizer_name") or model_name
    out_dir    = os.path.join(cfg.get("output_dir","outputs"),"orpo", os.path.basename(args.sft_ckpt)+"-orpo")

    use_unsloth = bool(cfg.get("unsloth",{}).get("enable", False)) or (bool(cfg["lora"].get("qlora", False)) and bool(cfg["lora"].get("load_in_4bit", False)))

    if use_unsloth:
        model, tok = FastLanguageModel.from_pretrained(
            model_name=model_name,
            max_seq_length=int(cfg["sft"].get("max_seq_len", 1024)),
            load_in_4bit=bool(cfg["lora"].get("load_in_4bit", True)),
        )
        if tok.pad_token is None: tok.pad_token = tok.eos_token
        l = cfg["lora"]
        base = FastLanguageModel.get_peft_model(
            model, r=int(l["r"]), lora_alpha=int(l["alpha"]), lora_dropout=float(l["dropout"]), target_modules=l["target_modules"]
        )
        model = PeftModel.from_pretrained(base, args.sft_ckpt)
    else:
        tok = AutoTokenizer.from_pretrained(tok_name, use_fast=True)
        if tok.pad_token is None: tok.pad_token = tok.eos_token
        bnb = None
        if cfg["lora"].get("qlora", False) and cfg["lora"].get("load_in_4bit", False):
            bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16)
        base = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", quantization_config=bnb)
        l = cfg["lora"]
        peft_cfg = LoraConfig(r=int(l["r"]), lora_alpha=int(l["alpha"]), lora_dropout=float(l["dropout"]), target_modules=l["target_modules"], task_type="CAUSAL_LM")
        base = get_peft_model(base, peft_cfg)
        model = PeftModel.from_pretrained(base, args.sft_ckpt)

    try:
        model.config.attn_implementation = "sdpa"
    except Exception:
        pass

    ds = load_dataset("json", data_files={"train": cfg["pref"]["train_file"], "validation": cfg["pref"]["val_file"]})
    ds = ds.map(lambda ex: {"prompt": format_dpo_prompt(ex["prompt"]), "chosen": ex["chosen"], "rejected": ex["rejected"]})

    lam      = float(cfg["orpo"].get("lambda", 0.5))
    bs_tr     = int(cfg["orpo"].get("per_device_train_batch_size", 2))
    bs_ev     = int(cfg["orpo"].get("per_device_eval_batch_size", 2))
    gas       = int(cfg["orpo"].get("gradient_accumulation_steps", 8))
    lr        = float(cfg["orpo"].get("lr", 1e-5))
    eval_s    = int(cfg["orpo"].get("eval_steps", 100))
    save_s    = int(cfg["orpo"].get("save_steps", 100))
    log_s     = int(cfg["orpo"].get("logging_steps", 10))
    max_steps = int(cfg["orpo"].get("max_steps", 300))

    tr_sig = inspect.signature(ORPOTrainer.__init__)
    kwargs = {"model": model, "train_dataset": ds["train"], "eval_dataset": ds["validation"]}
    if "processing_class" in tr_sig.parameters:
        kwargs["processing_class"] = tok
    elif "tokenizer" in tr_sig.parameters:
        kwargs["tokenizer"] = tok
    if "orpo_lambda" in tr_sig.parameters:
        kwargs["orpo_lambda"] = lam

    try:
        from trl import ORPOConfig
        cfgsig = inspect.signature(ORPOConfig)
        cfg_dict = {
            "output_dir": out_dir,
            "per_device_train_batch_size": bs_tr,
            "per_device_eval_batch_size": bs_ev,
            "gradient_accumulation_steps": gas,
            "learning_rate": lr,
            "logging_steps": log_s,
            "evaluation_strategy": "steps",
            "eval_steps": eval_s,
            "save_steps": save_s,
            "bf16": True,
            "max_steps": max_steps,
            "report_to": [],
        }
        if "orpo_lambda" in cfgsig.parameters:
            cfg_dict["orpo_lambda"] = lam
        oc = ORPOConfig(**{k:v for k,v in cfg_dict.items() if k in cfgsig.parameters})
        trainer = ORPOTrainer(args=oc, **kwargs)
    except Exception:
        trainer = ORPOTrainer(
            **kwargs,
            orpo_lambda=lam,
            args=dict(
                output_dir=out_dir,
                per_device_train_batch_size=bs_tr,
                per_device_eval_batch_size=bs_ev,
                gradient_accumulation_steps=gas,
                learning_rate=lr,
                logging_steps=log_s,
                evaluation_strategy="steps",
                eval_steps=eval_s,
                save_steps=save_s,
                bf16=True,
                max_steps=max_steps,
                report_to=[],
            ),
            max_length=1024, max_prompt_length=768
        )

    trainer.train()
    trainer.save_model(out_dir); tok.save_pretrained(out_dir)
    print(f"Saved ORPO LoRA to {out_dir}")

if __name__ == "__main__":
    main()
