import unsloth
from unsloth import FastLanguageModel

from torch.backends.cuda import sdp_kernel
sdp_kernel(enable_flash=False, enable_math=True, enable_mem_efficient=True)


import os, yaml, torch, inspect
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import PeftModel, LoraConfig, get_peft_model
from scripts.utils import format_dpo_prompt

from trl import DPOTrainer
_HAS_DPOCFG = False
try:
    from trl import DPOConfig
    _HAS_DPOCFG = True
except Exception:
    _HAS_DPOCFG = False

def load_cfg(p):
    with open(p,"r",encoding="utf-8") as f: return yaml.safe_load(f)

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/base.yaml")
    ap.add_argument("--sft_ckpt", required=True)
    args = ap.parse_args()
    cfg = load_cfg(args.config)

    model_name = cfg.get("model_name")
    tok_name   = cfg.get("tokenizer_name") or model_name
    out_dir    = os.path.join(cfg.get("output_dir","outputs"),"dpo", os.path.basename(args.sft_ckpt)+"-dpo")

    use_unsloth = bool(cfg.get("unsloth",{}).get("enable", False)) or (bool(cfg["lora"].get("qlora", False)) and bool(cfg["lora"].get("load_in_4bit", False)))

    if use_unsloth:
        model, tok = FastLanguageModel.from_pretrained(
            model_name=model_name,
            max_seq_length=int(cfg["sft"].get("max_seq_len", 1024)),
            load_in_4bit=bool(cfg["lora"].get("load_in_4bit", True)),
        )
        if tok.pad_token is None: tok.pad_token = tok.eos_token
        l = cfg["lora"]
        base = FastLanguageModel.get_peft_model(
            model, r=int(l["r"]), lora_alpha=int(l["alpha"]), lora_dropout=float(l["dropout"]), target_modules=l["target_modules"]
        )
        model = PeftModel.from_pretrained(base, args.sft_ckpt)
    else:
        tok = AutoTokenizer.from_pretrained(tok_name, use_fast=True)
        if tok.pad_token is None: tok.pad_token = tok.eos_token
        bnb = None
        if cfg["lora"].get("qlora", False) and cfg["lora"].get("load_in_4bit", False):
            bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16)
        base = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", quantization_config=bnb)
        l = cfg["lora"]
        peft_cfg = LoraConfig(r=int(l["r"]), lora_alpha=int(l["alpha"]), lora_dropout=float(l["dropout"]), target_modules=l["target_modules"], task_type="CAUSAL_LM")
        base = get_peft_model(base, peft_cfg)
        model = PeftModel.from_pretrained(base, args.sft_ckpt)

    try:
        model.config.attn_implementation = "sdpa"
    except Exception:
        pass

    dpo_ds = load_dataset("json", data_files={"train": cfg["pref"]["train_file"], "validation": cfg["pref"]["val_file"]})
    dpo_ds = dpo_ds.map(lambda ex: {"prompt": format_dpo_prompt(ex["prompt"]), "chosen": ex["chosen"], "rejected": ex["rejected"]})

    beta      = float(cfg["dpo"].get("beta", 0.1))
    bs_tr     = int(cfg["dpo"].get("per_device_train_batch_size", 2))
    bs_ev     = int(cfg["dpo"].get("per_device_eval_batch_size", 2))
    gas       = int(cfg["dpo"].get("gradient_accumulation_steps", 8))
    lr        = float(cfg["dpo"].get("lr", 1e-5))
    eval_s    = int(cfg["dpo"].get("eval_steps", 100))
    save_s    = int(cfg["dpo"].get("save_steps", 100))
    log_s     = int(cfg["dpo"].get("logging_steps", 10))
    max_steps = int(cfg["dpo"].get("max_steps", 300))

    _tr_sig = inspect.signature(DPOTrainer.__init__)
    trainer_kwargs = {"model": model, "train_dataset": dpo_ds["train"], "eval_dataset": dpo_ds["validation"]}
    if "processing_class" in _tr_sig.parameters:
        trainer_kwargs["processing_class"] = tok
    elif "tokenizer" in _tr_sig.parameters:
        trainer_kwargs["tokenizer"] = tok
    if "beta" in _tr_sig.parameters:
        trainer_kwargs["beta"] = beta

    if _HAS_DPOCFG:
        from inspect import signature as _sig
        _cfg_sig = _sig(DPOConfig)
        cfg_dict = {
            "output_dir": out_dir,
            "per_device_train_batch_size": bs_tr,
            "per_device_eval_batch_size": bs_ev,
            "gradient_accumulation_steps": gas,
            "learning_rate": lr,
            "logging_steps": log_s,
            "evaluation_strategy": "steps",
            "eval_steps": eval_s,
            "save_steps": save_s,
            "bf16": True,
            "max_steps": max_steps,
            "report_to": [],
        }
        if "beta" in _cfg_sig.parameters:
            cfg_dict["beta"] = beta
        dpo_args = DPOConfig(**{k:v for k,v in cfg_dict.items() if k in _cfg_sig.parameters})
        trainer = DPOTrainer(args=dpo_args, **trainer_kwargs)
    else:
        trainer = DPOTrainer(
            **trainer_kwargs,
            beta=beta,
            args=dict(
                output_dir=out_dir,
                per_device_train_batch_size=bs_tr,
                per_device_eval_batch_size=bs_ev,
                gradient_accumulation_steps=gas,
                learning_rate=lr,
                logging_steps=log_s,
                evaluation_strategy="steps",
                eval_steps=eval_s,
                save_steps=save_s,
                bf16=True,
                max_steps=max_steps,
                report_to=[],
            ),
            max_length=1024, max_prompt_length=768
        )

    trainer.train()
    trainer.save_model(out_dir); tok.save_pretrained(out_dir)
    print(f"Saved DPO LoRA to {out_dir}")

if __name__ == "__main__":
    main()
