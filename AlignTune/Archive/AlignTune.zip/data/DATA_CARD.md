# Data Card — Demo Instruction & Preference Sets
Purpose: tiny examples so the pipeline runs anywhere.
- **SFT**: JSONL with {"instruction","input","output"}.
- **Preference (DPO/SimPO/ORPO)**: JSONL with {"prompt","chosen","rejected"}.
Replace with your domain data for meaningful results.
